#!/usr/bin/env python
import pandas as pd
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder

from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import Adam
iris_data=load_iris()
X=iris_data.data
y_=iris_data.target.reshape(-1,1)
#..........onehot encode the class labels.....
encoder=OneHotEncoder()
y=encoder.fit_transform(y_)
#print y
#...........spliting data....................
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.20)

#................build model.................

model=Sequential()
model.add(Dense(10,input_shape=(4,),activation='relu',name='fc1'))
model.add(Dense(10,activation='relu',name='fc2'))
model.add(Dense(3,activation='softmax',name='output'))
#...................Adam optimizer................
optimizer=Adam(lr=0.001)
model.compile(optimizer,loss='categorical_crossentropy',metrics=['accuracy'])
print('Neural network model summary:')
print(model.summary())
#.................train the model.................
model.fit(X_train,y_train,verbose=2,batch_size=5,epochs=10)

#...................test on unseen data............

results=model.evaluate(X_test,y_test)
print('Final test set loss:{:4f}'.format(results[0]))
print('final test set accuracy:{:4f}'.format(results[1]))
