#!/usr/bin/env python
import numpy as np
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder

from kears.model import Sequential
from keras.layers import Dense
from keras.optimizers import Adam
boston_data=load_boston()
X=boston_data.data
y=boston_data.target.reshape(-1,1)
#.................one hot encode the class labels...........
encoder=OneHotEncoder()
y=encoder.fit_transform(y_)
print y

#.................spliting data.............................
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.20)

#...................build model.............................

model=Sequential()
model.add(Dense(10,input_shape=(4,),activation='relu',name='fc1'))
model.add(Dense(10,activation='relu',name='fc2'))
model.add(Dense(3,activation='softmax',name='output'))


